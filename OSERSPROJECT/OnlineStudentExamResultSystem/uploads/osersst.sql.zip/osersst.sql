-- phpMyAdmin SQL Dump
-- version 2.11.9.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 01, 2018 at 08:04 AM
-- Server version: 5.0.67
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `osers`
--

-- --------------------------------------------------------

--
-- Table structure for table `student1`
--

CREATE TABLE IF NOT EXISTS `student1` (
  `St_ID` varchar(30) default NULL,
  `St_Name` varchar(30) default NULL,
  `PhNO` varchar(15) default NULL,
  `Birthdate` varchar(15) default NULL,
  `Address` varchar(30) default NULL,
  `deptID` varchar(20) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student1`
--

INSERT INTO `student1` (`St_ID`, `St_Name`, `PhNO`, `Birthdate`, `Address`, `deptID`) VALUES
('6299', 'Htet Htet Zin', '09 772061164', '12/3/2001', 'Mandalay', '1CST'),
('6301', 'May Myat Noe Oo', '09 772061161', '12/3/2001', 'Mandalay', '1CST'),
('6302', 'Nway Su Min', '09 772061162', '12/3/2001', 'Mandalay', '1CST'),
('6303', 'Thiha Zaw', '09 772061163', '12/3/2001', 'Mandalay', '1CST'),
('6304', 'Min Aant Htoo Aung', '09 772061165', '12/3/2001', 'Mandalay', '1CST'),
('6305', 'Hein Htet Aung', '09 772061166', '12/3/2001', 'Mandalay', '1CST'),
('6306', 'Su Aung', '09 772061167', '12/3/2001', 'Mandalay', '1CST'),
('6307', 'Hnin Ei San', '09 772061168', '12/3/2001', 'Mandalay', '1CST'),
('6308', 'Khaing Thinzar Thwe', '09 772061169', '12/3/2001', 'Mandalay', '1CST'),
('6309', 'Aung Htet Nay', '09 772061110', '12/3/2001', 'Mandalay', '1CST'),
('6310', 'Htet Htet Yan Naing', '09 772061111', '12/3/2001', 'Mandalay', '1CST'),
('6311', 'Naing Lin Zaw', '09 772061112', '12/3/2001', 'Mandalay', '1CST'),
('6312', 'Vijay Kumar', '09 772061113', '12/3/2001', 'Mandalay', '1CST'),
('6313', 'Yin Moe Naing', '09 772061114', '12/3/2001', 'Mandalay', '1CST'),
('6314', 'Ye Lwin Oo', '09 772061115', '12/3/2001', 'Mandalay', '1CST');

-- --------------------------------------------------------

--
-- Table structure for table `student2`
--

CREATE TABLE IF NOT EXISTS `student2` (
  `St_ID` varchar(30) default NULL,
  `St_Name` varchar(30) default NULL,
  `PhNO` varchar(15) default NULL,
  `Birthdate` varchar(15) default NULL,
  `Address` varchar(30) default NULL,
  `deptID` varchar(20) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student2`
--

INSERT INTO `student2` (`St_ID`, `St_Name`, `PhNO`, `Birthdate`, `Address`, `deptID`) VALUES
('6145', 'Win Nandar Kyaw', '09 772061164', '12/3/2000', 'Mandalay', '2CS'),
('6126', 'Thet Lin Latt', '09 772061161', '12/3/2000', 'Mandalay', '2CS'),
('6174', 'Kay Zin Mon', '09 772061162', '12/3/2000', 'Mandalay', '2CS'),
('6183', 'Than Non Swe', '09 772061163', '12/3/2000', 'Mandalay', '2CS'),
('6195', 'Lin Sandi Soe', '09 772061165', '12/3/2000', 'Mandalay', '2CS'),
('6208', 'Su Myat Hnin', '09 772061166', '12/3/2000', 'Mandalay', '2CS'),
('6155', 'Kay Thi Kyaw', '09 772061167', '12/3/2000', 'Mandalay', '2CS'),
('6187', 'San San Myint', '09 772061168', '12/3/2000', 'Mandalay', '2CS'),
('6114', 'Seint Seint Moe', '09 772061169', '12/3/2000', 'Mandalay', '2CS'),
('6132', 'Shwe Sin Oo', '09 772061110', '12/3/2000', 'Mandalay', '2CS'),
('6124', 'Khaing Su Thar', '09 772061111', '12/3/2000', 'Mandalay', '2CS'),
('6131', 'Moe Sett', '09 772061112', '12/3/2000', 'Mandalay', '2CS'),
('6202', 'Saw Nae Tar Htoo', '09 772061113', '12/3/2000', 'Mandalay', '2CS'),
('6119', 'Nang Khin Myat Noe ', '09 772061114', '12/3/2000', 'Mandalay', '2CS'),
('6138', 'Thae Su Kysw', '09 772061115', '12/3/2000', 'Mandalay', '2CS');

-- --------------------------------------------------------

--
-- Table structure for table `student3`
--

CREATE TABLE IF NOT EXISTS `student3` (
  `St_ID` varchar(30) default NULL,
  `St_Name` varchar(30) default NULL,
  `PhNO` varchar(15) default NULL,
  `Birthdate` varchar(15) default NULL,
  `Address` varchar(30) default NULL,
  `deptID` varchar(20) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student3`
--

INSERT INTO `student3` (`St_ID`, `St_Name`, `PhNO`, `Birthdate`, `Address`, `deptID`) VALUES
('5881', 'Nang Zin Moe', '09 772061164', '12/3/1999', 'Mandalay', '3CS'),
('5807', 'Sai Horm Kham', '09 772061161', '12/3/1999', 'Mandalay', '3CS'),
('5779', 'Yupar Htay Win', '09 772061162', '12/3/1999', 'Mandalay', '3CS'),
('5784', 'Thaw Zin Myint', '09 772061163', '12/3/1999', 'Mandalay', '3CS'),
('5804', 'May Myat Noe Khin', '09 772061165', '12/3/1999', 'Mandalay', '3CS'),
('5866', 'Yu Yu Naing', '09 772061166', '12/3/1999', 'Mandalay', '3CS'),
('5800', 'Cherry Aung', '09 772061167', '12/3/1999', 'Mandalay', '3CS'),
('5946', 'Htun Tauk', '09 772061168', '12/3/1999', 'Mandalay', '3CS'),
('5844', 'Thin Yu Wai', '09 772061169', '12/3/1999', 'Mandalay', '3CS'),
('5819', 'Ei Hnin Htet Aung', '09 772061110', '12/3/1999', 'Mandalay', '3CS'),
('5653', 'Sai Han Lin Aung', '09 772061111', '12/3/1999', 'Mandalay', '3CS'),
('5855', 'Mi Mi Zaw', '09 772061112', '12/3/1999', 'Mandalay', '3CS'),
('5896', 'Yu Mon Khaing', '09 772061113', '12/3/1999', 'Mandalay', '3CS'),
('5796', 'Kalayar Moe Myint ', '09 772061114', '12/3/1999', 'Mandalay', '3CS'),
('5780', 'Zin Zin Htike', '09 772061115', '12/3/1999', 'Mandalay', '3CS');
